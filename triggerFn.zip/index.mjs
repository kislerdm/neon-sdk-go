import{createRequire as ___cr}from'module';import{fileURLToPath as ___f}from'url';import{dirname as ___d}from'path';const require=___cr(import.meta.url);const __filename=___f(import.meta.url);const __dirname=___d(__filename);

// index.ts
async function index_default() {
  return new Response("Hello, World!");
}
export {
  index_default as default
};
